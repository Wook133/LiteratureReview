package nmu.wrap302.devilliers;

import java.util.Comparator;

/**
 * Created by scruf on 25-Feb-18.
 */
public class Entry implements Comparable<Entry>
{
    public int key;
    public int value;

    public Entry(int key, int value) {
        this.key = key;
        this.value = value;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    @Override
    public int compareTo(Entry other)
    {
        if (this.getValue() > other.getValue())
        {
            return 1;
        }
        else if (this.getValue() == other.getValue())
        {
            return 0;
        }
        else
        {
            return -1;
        }
    }


    public class EntryCompare implements Comparator<Entry>
    {
        @Override
        public int compare(Entry me, Entry other)
        {
            if (me.getValue() > other.getValue())
            {
                return 1;
            }
            else if (me.getValue() == other.getValue())
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }




    }

}

