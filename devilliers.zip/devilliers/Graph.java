package nmu.wrap302.devilliers;
import javafx.util.Pair;

import javax.print.attribute.IntegerSyntax;
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
/**
 * Created by scruf on 16-Feb-18.
 */
class Graph {
    public int V;   // No. of vertices
    public LinkedList<Integer> adj[]; //Adjacency Lists


    // Constructor
    Graph(int v) {
        V = v;
        adj = new LinkedList[v];
        for (int i = 0; i < v; ++i) {
            adj[i] = new LinkedList();
        }
    }

    // Function to add an edge into the graph
    void addEdge(int v, int w) {
        adj[v].add(w);
    }

    void removeEdge(int v, int w)
    {
        adj[v].remove(w);
    }


    // A function used by DFS
    void DFSUtil(int v, boolean visited[], List<Integer> lPath) {
        // Mark the current node as visited and print it
        visited[v] = true;
        System.out.print(v + " ");
        lPath.add(v);
        //sPath = sPath + " ";

        // Recur for all the vertices adjacent to this vertex
        Iterator<Integer> i = adj[v].listIterator();
        while (i.hasNext()) {
            int n = i.next();
            if (!visited[n])
                DFSUtil(n, visited, lPath);
        }
    }

    // The function to do DFS traversal. It uses recursive DFSUtil()
    void DFS() {
        // Mark all the vertices as not visited(set as
        // false by default in java)
        boolean visited[] = new boolean[V];
        String sPath = "";
        List<Integer> lPath = new ArrayList<Integer>();

        // Call the recursive helper function to print DFS traversal
        // starting from all vertices one by one
        for (int i = 0; i < V; ++i)
            if (visited[i] == false)
                DFSUtil(i, visited, lPath);
    }

    // prints BFS traversal from a given source s
    String BFS(int s, int f) {
        // Mark all the vertices as not visited(By default
        // set as false)
        boolean visited[] = new boolean[V];
        String sPath = " ";

        // Create a queue for BFS
        LinkedList<Integer> queue = new LinkedList<Integer>();

        // Mark the current node as visited and enqueue it
        visited[s] = true;
        queue.add(s);

        /*Boolean broken = false;*/
        while ((queue.size() != 0)/* && (broken == false)*/) {
            // Dequeue a vertex from queue and print it
            s = queue.poll();
            sPath = sPath + " ";

            // Get all adjacent vertices of the dequeued vertex s
            // If a adjacent has not been visited, then mark it
            // visited and enqueue it
            Iterator<Integer> i = adj[s].listIterator();
            while ((i.hasNext())) {
                int n = i.next();
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                }
                /*if (n == f) {
                    broken = true;
                    break;
                }*/
            }
        }
        return sPath;
    }


    public String BreadthSearch(int s, int f)
    {
        String sExplored = "";

        //FIFO
        ArrayList<Integer> Frontier = new ArrayList<Integer>(); //use like queue, pop first add at end
        HashSet<Integer> Explored = new HashSet<Integer>();
        Iterator<Integer> i = adj[s].listIterator();

        List<Integer> path = new ArrayList<Integer>();
        while (i.hasNext()) {
            Integer iad = i.next();
            Frontier.add(iad);
            path.add(iad);
        }
        while (!(Frontier.contains(f)))
        {
            Integer cur = Frontier.remove(0);

            Explored.add(cur);
            Iterator<Integer> iter = adj[cur].listIterator();
            while (iter.hasNext())
            {
                Integer iAdder = iter.next();
                Boolean bF = Frontier.contains(iAdder);
                Boolean bE = Explored.contains(iAdder);
                if ((bF == false) && (bE == false))
                {
                    Frontier.add(iAdder);
                }
            }
        }
        Iterator<Integer> itrExplored = Explored.iterator();
        while (itrExplored.hasNext())
        {
            sExplored = sExplored + itrExplored.next() + " ";
        }
        int iFront = 0;
        int iStop = Frontier.size() - 1;
        while (iFront <= iStop)
        {
            int q = Frontier.get(iFront);
            if (q != f) {
                sExplored = sExplored + q + " ";

                iFront = iFront + 1;
            }
            else if (q == f)
            {
                sExplored = sExplored + q + " ";

               // iFront = iFront + iStop;
                break;
            }
        }
        System.out.println(sExplored);
        return sExplored;

    }

    public void DepthLimitedSearch(Integer s, Integer f, Integer t)
    {
        String sPath = s.toString();
        List<Integer> Frontier = new Stack<Integer>();//lifo
        HashSet<Integer> Explored = new HashSet<Integer>();
        Iterator<Integer> i = adj[s].listIterator();

        while (i.hasNext()) {
            Integer iad = i.next();
            System.out.println("Populate from intial point's neighbors " + s);
            Frontier.add(iad);
        }
        while (Frontier.contains(f) == false)
        {
            int iremover = Frontier.size() - 1;
            int idepth = 0;
            Integer cur = Frontier.get(iremover);
            sPath = sPath + " " + cur;
            Explored.add(cur);
            //System.out.println("Explored " + cur);
            if (idepth < t)
            {
                idepth++;

                Iterator<Integer> iter = adj[cur].listIterator();//adj List for cur

                while (iter.hasNext())
                {
                    Integer iNeighbor = iter.next();
                    //System.out.println("Neighbours " + iNeighbor);
                    boolean bf = Frontier.contains(iNeighbor);
                    //System.out.println(bf);
                    boolean be = Explored.contains(iNeighbor);
                    if ((bf == false) && (be == false))
                    {
                        Frontier.add(iNeighbor);
                        //System.out.println("Pushing " + iNeighbor);
                    }
                }
            }
            else
            {
                System.out.println("No path under that threshold");
                sPath = "No Path, increasing threshold";
            }
            Frontier.remove(iremover);
        }
        sPath = sPath + " " + f;
        System.out.println(sPath);
    }

    public String DepthFirst(Integer s, Integer f)
    {
        //List<Integer> lpath = new ArrayList<Integer>();
        //lpath.add(s);
        String sPath = s.toString();
        List<Integer> StackPath = new Stack<Integer>();//lifo
        List<Integer> Frontier = new Stack<Integer>();//lifo
        HashSet<Integer> Explored = new HashSet<Integer>();
        Iterator<Integer> i = adj[s].listIterator();

        while (i.hasNext()) {
            Integer iad = i.next();
            System.out.println("Populate from intial point's neighbors " + s);

            Frontier.add(iad);
        }
        while (Frontier.contains(f) == false)
        {
            int iremover = Frontier.size() - 1;
            Integer cur = Frontier.get(iremover);
            //lpath.add(cur);
            sPath = sPath + " " + cur;
            Explored.add(cur);
            Iterator<Integer> iter = adj[cur].listIterator();//adj List for cur

            while (iter.hasNext())
            {
                Integer iNeighbor = iter.next();
                    //System.out.println("Neighbours " + iNeighbor);
                boolean bf = Frontier.contains(iNeighbor);
                //System.out.println(bf);
                boolean be = Explored.contains(iNeighbor);
                if ((bf == false) && (be == false))
                {
                    Frontier.add(iNeighbor);
                    //System.out.println("Pushing " + iNeighbor);
                }
            }
            Frontier.remove(iremover);
        }
        sPath = sPath + " " + f;
        //lpath.add(f);
        System.out.println(sPath);
        return sPath;

    }







    public Boolean DLS(int src, int target, int limit)
    {
        if (src == target)
        {
            return true;
        }

        if (limit <= 0)
        {
            return false;
        }

        LinkedList<Integer> adjS = this.adj[src];

        for (Integer adji : adjS)
        {
            if (DLS(adji, target, limit))
            {
                return true;
            }
        }
        return false;
    }




    public Boolean IDDFS(int src, int target, int max_depth)
    {
        // Repeatedly depth-limit search till the
        // maximum depth.
        for (int limit = 0; limit <= max_depth; limit++)
        {
            if (DLS(src, target, limit))
            {
                return true;
            }
        }
        return false;
    }



}
