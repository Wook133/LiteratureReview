package nmu.wrap302.devilliers;

import java.util.*;

/**
 * Created by scruf on 25-Feb-18.
 */
public class Weight
{
    public class ek
    {
        public Integer key;
        public Integer value;

        public ek(Integer k, Integer v)
        {
            this.key = k;
            this.value = v;
        }

        @Override
        public String toString()
        {
            String s = key + " : " + value;
            return s;
        }
    }

    public class EntryComparator implements Comparator<ek>
    {
        @Override
        public int compare(ek o1, ek o2) {
            if(o1.value == o2.value)
                return 0;
            else if(o1.value < o2.value)
                return -1;
            else
                return 1;
        }
    }

    public int V;   // No. of vertices
    public LinkedList<Integer> adj[]; //Adjacency Lists
    public ArrayList<Integer> weights;


    // Constructor
    Weight(int v) {
        V = v;
        adj = new LinkedList[v];
        weights  = new ArrayList<Integer>();
        for (int i = 0; i < v; ++i) {
            adj[i] = new LinkedList();
            weights.add(0);
        }
    }

    void addWeights(int v, int iweight)
    {
        weights.set(v, iweight);
    }

    // Function to add an edge into the graph
    void addEdge(int v, int w) {
        adj[v].add(w);
    }

    public String UniformSearch(Integer s, Integer f)
    {
        String sPath = "";


        EntryComparator comparator = new EntryComparator();
        List<ek> Frontier = new LinkedList<ek>();//priority q
        Frontier.add(new ek(s, weights.get(s)));
        HashSet<Integer> Explored = new HashSet<Integer>();
        Iterator<Integer> i = adj[s].listIterator();

        Collections.sort(Frontier, comparator);
        Set<ek> setFront = new HashSet<ek>();
        setFront.addAll(Frontier);
        Frontier.clear();
        Frontier.addAll(setFront);
        Collections.sort(Frontier, comparator);

        while (i.hasNext()) {
            Integer iad = i.next();
            Integer iw = weights.get(iad);
            ek q = new ek(iad, iw);
            //System.out.println(q.toString());
            Frontier.add(q);
            Collections.sort(Frontier, comparator);
            setFront = new HashSet<ek>();
            setFront.addAll(Frontier);
            Frontier.clear();
            Frontier.addAll(setFront);
            Collections.sort(Frontier, comparator);
        }//add initial state to frontier


        Collections.sort(Frontier, comparator);

        setFront = new HashSet<ek>();
        setFront.addAll(Frontier);
        Frontier.clear();
        Frontier.addAll(setFront);
        Collections.sort(Frontier, comparator);

        while (Frontier.isEmpty() == false)
        {
            ek cur = Frontier.remove(0);

            if (Explored.contains(cur.key) == false) {
                sPath = sPath + " " + cur.key;
                //System.out.println(cur.toString());//print frontier if not explored
            }
            Collections.sort(Frontier, comparator);

            setFront = new HashSet<ek>();
            setFront.addAll(Frontier);
            Frontier.clear();
            Frontier.addAll(setFront);
            Collections.sort(Frontier, comparator);

            Integer ivCur = cur.key;
            Integer iwCur = cur.value;
            //Frontier Dequeued
            if (ivCur == f)
            {
                System.out.println("Goal: " + ivCur);
                //Your Goal has been reached
                Explored.add(ivCur);
                break;
            }
            Explored.add(ivCur);
            //System.out.println(ivCur);
            //add cur to explored
            Iterator<Integer> iter = adj[ivCur].listIterator();
            while (iter.hasNext())//iterate through adjacency list
            {
                Integer iAdjV = iter.next();
                Boolean binExp = Explored.contains(iAdjV);
                if (binExp == false)
                {
                    ek searchVertex = new ek( iAdjV, -1);
                    Integer inFront = Collections.binarySearch(Frontier, searchVertex, comparator);
                    Boolean binFront = false;
                    binFront = inFront >= 0;
                    if (binFront == false)
                    {
                        ek adder = new ek(iAdjV, weights.get(iAdjV));
                        Frontier.add(adder);
                        Collections.sort(Frontier, comparator);

                        setFront = new HashSet<ek>();
                        setFront.addAll(Frontier);
                        Frontier.clear();
                        Frontier.addAll(setFront);
                        Collections.sort(Frontier, comparator);

                    }
                    else
                    {
                        Integer iw = Frontier.get(inFront).value;
                        if (weights.get(iAdjV) < iw)
                        {
                            Frontier.remove(inFront);
                            Collections.sort(Frontier, comparator);
                            ek adder = new ek(iAdjV, weights.get(iAdjV));
                            Collections.sort(Frontier, comparator);

                            setFront = new HashSet<ek>();
                            setFront.addAll(Frontier);
                            Frontier.clear();
                            Frontier.addAll(setFront);
                            Collections.sort(Frontier, comparator);

                        }
                    }
                }
            }
        }
        System.out.println(sPath);
        return sPath;
    }



}
