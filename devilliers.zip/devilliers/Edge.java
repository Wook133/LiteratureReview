package nmu.wrap302.devilliers;

/**
 * Created by scruf on 16-Feb-18.
 */
public class Edge {
    public Vertex a;

    public Edge(Vertex a) {
        this.a = a;
    }
}
