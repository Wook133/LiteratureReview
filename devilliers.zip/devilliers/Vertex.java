package nmu.wrap302.devilliers;

import java.util.ArrayList;

/**
 * Created by scruf on 16-Feb-18.
 */
public class Vertex
{
    public int iweight;
    public int id;
    public ArrayList<Edge> adjList;

    public Vertex()
    {
        this.iweight = 0;
        this.id = 0;
    }

    public Vertex(int iweight, int id) {
        this.iweight = iweight;
        this.id = id;
        adjList = new ArrayList<Edge>();
    }

    public void addEdge(Edge E)
    {
        adjList.add(E);
    }



}
