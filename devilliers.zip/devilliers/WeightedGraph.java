package nmu.wrap302.devilliers;

import javafx.util.Pair;

import java.util.*;

/**
 * Created by scruf on 25-Feb-18.
 */
public class WeightedGraph {
    public int V;   // No. of vertices
    public LinkedList<Integer> adj[]; //Adjacency Lists
    public ArrayList<Integer> weights;


    // Constructor
    WeightedGraph(int v) {
        V = v;
        adj = new LinkedList[v];
        weights  = new ArrayList<Integer>();
        for (int i = 0; i < v; ++i) {
            adj[i] = new LinkedList();
            weights.add(0);
        }
    }



    void addWeights(int v, int iweight)
    {
        weights.set(v, iweight);
    }

    // Function to add an edge into the graph
    void addEdge(int v, int w) {
        adj[v].add(w);
    }

    public void UniformSearch(int s, int f)
    {
        String sPath = "";
        PriorityQueue<Entry> tempFrontier = new PriorityQueue<>();
        PriorityQueue<Entry> Frontier = new PriorityQueue<>();
        HashSet<Integer> Explored = new HashSet<Integer>();
        Iterator<Integer> i = adj[s].listIterator();
        while(i.hasNext())
        {
            Integer iad = i.next();
            Integer iw = weights.get(iad);//i doubt it'll look at walls as vertices as they have empty adjacency lists
            Entry enter = new Entry(iad, iw);
            System.out.println(iad + " : " + iw);
            Frontier.add(enter);
        }
        do {
            Entry eCur = Frontier.poll();
            Integer iw = eCur.getValue();
            Integer iv = eCur.getKey();
            System.out.println(iv + " : " + iw);
            if (iv == f)
            {
                System.out.println("A path has been found");
                break;
            }
            Explored.add(iv);// add first frontier node (according to weight) to explored

            Iterator<Integer> iter = adj[iv].listIterator();
            while (iter.hasNext())//states reachable from cur
            {
                Integer intAdj = iter.next();
                if (Explored.contains(intAdj) == false)//if a given vertice is not in explored
                {
                    Boolean bIsInFrontier = false;
                    Iterator<Entry> entFront = Frontier.iterator();
                    while (entFront.hasNext())
                    {
                        Entry entTrav = entFront.next();
                        Integer ieV = entTrav.getKey();
                        Integer ieW = entTrav.getValue();
                        if (intAdj == ieV)
                        {
                            bIsInFrontier = true;
                            if (ieW < weights.get(intAdj))
                            {//remove the greater weighted vertice

                                Iterator<Entry> tempentFront = Frontier.iterator();
                                while (tempentFront.hasNext())
                                {
                                    Entry c = tempentFront.next();
                                    int itempw = c.getValue();
                                    int itempv = c.getKey();
                                    if (itempv != intAdj)
                                    {
                                        tempFrontier.add(new Entry(itempv, itempw));
                                    }
                                }
                                Frontier = tempFrontier;
                            }
                        }
                    }


                }

            }


            Boolean bExplored = false;// Explored.contains();
            Boolean bFrontier = false;



        } while (Frontier.size() > 0);








        Iterator<Integer> itrExplored = Explored.iterator();
        String sExplored = "";
        while (itrExplored.hasNext())
        {
            sExplored = sExplored + itrExplored.next() + " ";
        }
        System.out.println(sExplored);
    }


}
