package nmu.wrap302.devilliers;

import com.sun.org.apache.xpath.internal.operations.Equals;
import javafx.util.Pair;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.util.List;

public class Main {



    public static void main(String[] args) {
        Graph g = new Graph(70);
        //pathReverser("0 1 2 3 4 10 12 13", g, 0,0);

        ArrayList<Integer> path = new ArrayList<>();
        Weight wg = new Weight(70);
        System.out.println();
        ArrayList<String> inputList = new ArrayList<String>();


        try {


            //System.out.println(CountVertices(inputList));
            inputList = readTF();
            /*wg = makeWeightedGraph(inputList);
            wg.UniformSearch(3, 66);
            inputList = readTF1();
            wg = makeWeightedGraph(inputList);
            wg.UniformSearch(5, 214);
            inputList = readTF2();
            wg = makeWeightedGraph(inputList);
            wg.UniformSearch(50, 10049);*/
            //wg.UniformSearch(5, 214);
            //wg.UniformSearch(50, 10049);


            //printGraph(g);
           // System.out.println(g.adj.toString());
            inputList = readTF();
            g = makeGraph(inputList);
            //String s = g.BreadthSearch(3, 66);
            //g.DepthLimitedSearch(3, 66, 2);
            inputList = readTF1();
            g = makeGraph(inputList);
            //s = g.BreadthSearch(5, 214);
            //g.DepthLimitedSearch(5, 214, 1000);
            inputList = readTF2();
            g = makeGraph(inputList);
            //s = g.BreadthSearch(50, 10049);
            g.DepthLimitedSearch(50, 10049, 10);

            //String sBFS = g.BreadthSearch(3,66);

            //String sDLS = wg.UniformSearch(3,66);
            //String s = g.DepthFirst(3, 66);
            //System.out.println(s);
            //g.DFS();


            //g.BreadthSearch(5,214);

            //g.DLS(3, 66, 20);
            //g.DFS();

           // System.out.println(g.BFS(3, 66));
            //g.BFS(5,214);
            //g.BFS(50,10049);

           // Graph copyG = makeGraph(inputList);
            //pathReverser(s, g, 3, 66);
        }
        catch (Exception e)
        {
            System.out.println(e);
        }

   /*     System.out.println("Following is Breadth First Traversal "+
                "(starting from vertex 3)");

        g.DFS();*/
    }

    public static int CountVertices(ArrayList<String> arrS)
    {
        int icount = 0;
        for (int i = 0; i <= arrS.size() - 1; i++)
        {
            String scur = arrS.get(i);
            for (int j = 0; j <= scur.length() - 1; j++)
            {
                if (scur.charAt(j) != '0')
                {
                    icount ++;
                }
            }
        }
        return icount;
    }

    public static Graph makeGraph(ArrayList<String> arrS)
    {
        int iheight = 0;
        iheight = arrS.size();
        int iwidth = 0;
        //System.out.println(arrS.get(0).charAt(3));
        iwidth = arrS.get(0).length();
        System.out.println("X: " + iwidth);
        System.out.println("Y: " + iheight);
        int icount =iwidth * iheight;
        Graph g = new Graph(icount);

        int[][] TwoDimensions = mapper(iwidth, iheight);
        //int[][] Weights = weights(arrS, iwidth, iheight) ;
        g.addEdge((iwidth / 2), ((iwidth/2)+iwidth));
        g.addEdge((icount-1) - ((iwidth / 2)), (icount-1) - ((iwidth/2)+iwidth));
       // g.addEdge()//9950 - > 10050


        for (int y = 1; y <= iheight - 2; y++)
        {
            String scur = arrS.get(y);
            String sUp = arrS.get(y-1);
            String sDown = arrS.get(y+1);
            //System.out.println(scur);
            for (int x = 1; x <= iwidth - 2; x++)
            {
                char cUp = sUp.charAt(x);
                char cDown = sDown.charAt(x);

                char cLeft = scur.charAt(x-1);
                char cRight = scur.charAt(x+1);

                char ccur = scur.charAt(x);

                int ipos = TwoDimensions[x][y];
                int iup = TwoDimensions[x][y-1];
                int idown = TwoDimensions[x][y+1];
                int ileft = TwoDimensions[x-1][y];
                int iright = TwoDimensions[x+1][y];

                if (ccur != '0') {
                    if (cUp != '0')
                    {
                        g.addEdge(ipos, iup);
                        //g.addEdge(iup, ipos);
                    }
                    if (cDown != '0')
                    {
                        g.addEdge(ipos, idown);
                        //g.addEdge(iup, ipos);

                    }
                    if (cLeft != '0')
                    {
                        g.addEdge(ipos, ileft);
                        //g.addEdge(ileft, ipos);
                    }
                    if (cRight != '0')
                    {
                        g.addEdge(ipos, iright);
                        //g.addEdge(iright, ipos);
                    }
                }
            }
        }
        return g;
    }

    public static Weight makeWeightedGraph(ArrayList<String> arrS)
    {
        int iheight = 0;
        iheight = arrS.size();
        int iwidth = 0;
        //System.out.println(arrS.get(0).charAt(3));
        iwidth = arrS.get(0).length();
        System.out.println("X: " + iwidth);
        System.out.println("Y: " + iheight);
        int icount =iwidth * iheight;
        Weight wg = new Weight(icount);

        int[][] TwoDimensions = mapper(iwidth, iheight);
        int[][] Weights = weights(arrS, iwidth, iheight) ;
        wg.addEdge((iwidth / 2), ((iwidth/2)+iwidth));
        wg.addWeights((iwidth / 2), 1);
        wg.addEdge((icount-1) - ((iwidth / 2)), (icount-1) - ((iwidth/2)+iwidth));
        // g.addEdge()//9950 - > 10050
        for (int a = 0; a <= iheight - 1; a++)
        {
            for (int b = 0; b <= iwidth -1;b++)
            {
                int iv = TwoDimensions[b][a];
                int iw = Weights[b][a];
                wg.addWeights(iv, iw);
                //System.out.print(iw + " ");
            }
            System.out.println();
        }
        for (int y = 1; y <= iheight - 2; y++)
        {
            String scur = arrS.get(y);
            String sUp = arrS.get(y-1);
            String sDown = arrS.get(y+1);
            //System.out.println(scur);
            for (int x = 1; x <= iwidth - 2; x++)
            {
                char cUp = sUp.charAt(x);
                char cDown = sDown.charAt(x);

                char cLeft = scur.charAt(x-1);
                char cRight = scur.charAt(x+1);

                char ccur = scur.charAt(x);

                int ipos = TwoDimensions[x][y];

                int iup = TwoDimensions[x][y-1];
                int idown = TwoDimensions[x][y+1];
                int ileft = TwoDimensions[x-1][y];
                int iright = TwoDimensions[x+1][y];

                if (ccur != '0') {
                    if (cUp != '0')
                    {
                        wg.addEdge(ipos, iup);
                        //g.addEdge(iup, ipos);
                    }
                    if (cDown != '0')
                    {
                        wg.addEdge(ipos, idown);
                        //g.addEdge(iup, ipos);

                    }
                    if (cLeft != '0')
                    {
                        wg.addEdge(ipos, ileft);
                        //g.addEdge(ileft, ipos);
                    }
                    if (cRight != '0')
                    {
                        wg.addEdge(ipos, iright);
                        //g.addEdge(iright, ipos);
                    }
                }
            }
            //System.out.println(" ");
        }


        return wg;
    }

    public static int[][] mapper(int x, int y)
    {
        int[][] TwoDimensions = new int[x][y];
        int icount = 0;
        for (int i = 0; i <= y - 1; i++)
        {
            for (int j = 0; j <= x - 1; j++)
            {
                TwoDimensions[j][i] = icount;
                icount++;
               // System.out.print(TwoDimensions[j][i] + " ");
            }
          //  System.out.println();
        }
        return TwoDimensions;
    }

    public static int[][] weights(ArrayList<String> arrIN, int x, int y)
    {
        int[][] TwoDWeights = new int[x][y];
        int icount = 0;
        for (int i = 0; i <= arrIN.size() - 1; i ++)
        {
            String scur = arrIN.get(i);
            for (int j = 0; j <= scur.length() - 1; j++) {
                Character cur = scur.charAt(j);
                TwoDWeights[j][i] = Character.getNumericValue(cur);
               // System.out.print(TwoDWeights[j][i] );
            }
          //  System.out.println();
        }
        return TwoDWeights;
    }


    public static ArrayList<String> readTF() throws FileNotFoundException {
        String sout = "";
        ArrayList<String> arrS = new ArrayList<String>();
        // pass the path to the file as a parameter
        try {
            File file = new File("X:\\University\\2018\\Semester 1\\Capita Selecta\\src\\nmu\\wrap302\\devilliers\\Maze7x10.txt");

            Scanner sc = new Scanner(file);

            while (sc.hasNextLine()) {
                sout = sc.nextLine();
                //System.out.println(sout);
                arrS.add(sout);
            }

        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        //System.out.println("");
        return arrS;
    }
    public static ArrayList<String> readTF1() throws FileNotFoundException {
        String sout = "";
        ArrayList<String> arrS = new ArrayList<String>();
        // pass the path to the file as a parameter
        try {
            File file = new File("X:\\University\\2018\\Semester 1\\Capita Selecta\\src\\nmu\\wrap302\\devilliers\\Maze11x20.txt");

            Scanner sc = new Scanner(file);

            while (sc.hasNextLine()) {
                sout = sc.nextLine();
               // System.out.println(sout);
                arrS.add(sout);
            }

        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        //System.out.println("");
        return arrS;
    }
    public static ArrayList<String> readTF2() throws FileNotFoundException {
        String sout = "";
        ArrayList<String> arrS = new ArrayList<String>();
        // pass the path to the file as a parameter
        try {
            File file = new File("X:\\University\\2018\\Semester 1\\Capita Selecta\\src\\nmu\\wrap302\\devilliers\\Maze101x100.txt");

            Scanner sc = new Scanner(file);

            while (sc.hasNextLine()) {
                sout = sc.nextLine();
                //System.out.println(sout);
                arrS.add(sout);
            }

        }
        catch (Exception e)
        {
            System.out.println(e);
        }
       // System.out.println("");
        return arrS;
    }

    // A utility function to print the adjacency list
    // representation of graph
    static void printGraph(Graph graph)
    {
        for(int v = 0; v < graph.V; v++)
        {
            System.out.println("Adjacency list of vertex "+ v);
            System.out.print("head");
            for(Integer pCrawl: graph.adj[v]){
                System.out.print(" -> "+pCrawl);
            }
            System.out.println("\n");
        }
    }

    public static List<Integer> pathReverser(String sVertices, Graph g, int s, int f)
    {
        System.out.println("**********");
        List<Integer> Back = new ArrayList<Integer>();
        List<List<Integer>> PathsBack = new ArrayList<>();
        List<Integer> lin = new ArrayList<Integer>();
        List<Integer> lpath = new ArrayList<Integer>();
        Scanner scanner = new Scanner(sVertices);
        while (scanner.hasNextInt()) {
            lin.add(scanner.nextInt());
        }


        Collections.reverse(lin);

        for (int i = 0; i <= lin.size() - 1; i ++)
        {
            int j = lin.get(i);
            System.out.print(j + " ");
        }
        System.out.println("");
        System.out.println("*****************************");
        int k = 0;
        int icur = lin.get(k);
        lpath.add(icur);
        System.out.println("First: " + g.adj[f].getFirst());
        int iadd = g.adj[f].getFirst();
        System.out.println("Second: " + g.adj[iadd].getFirst());
        g.adj[f].clear();
        /*System.out.println("First: " + g.adj[f].getFirst());
        int iadd = g.adj[f].getFirst();
        System.out.println("Second: " + g.adj[iadd].getFirst());
        g.adj[f].clear();*/

        int icounter = 1;
        while ((lpath.contains(s) == false) && (icounter < 10))
        {
            Iterator<Integer> itr = g.adj[lin.get(iadd)].listIterator();
            while (itr.hasNext())
            {
                Integer j = itr.next();
                Back.add(j);
            }
            g.adj[lin.get(iadd)].removeAll(Back);
            for (int i = 0; i <= Back.size() - 1; i++)
            {


            }


            icounter++;





        }





        //g.adj[icur].remove(0);
        //System.out.println("Third: " + g.adj[icur].getFirst());






      //  Iterator<Integer> it = g.adj[lin.get(0)].listIterator();
     //   System.out.println(it.next());
       /* while ((lpath.contains(s) == false))
        {
            Iterator<Integer> iter = g.adj[lin.get(icount)].listIterator();

            while (iter.hasNext())
            {
                Integer iNeigh = iter.next();
                System.out.println(iNeigh);
                Back.add(iNeigh);
                icount = lin.indexOf(iNeigh);

                /*if (lin.contains(iNeigh));
                {
                    int ipos = lin.indexOf(iNeigh);
                    icount = ipos;
                    lpath.add(iNeigh);
                }
                icount++;
                System.out.println(iNeigh);*/

           /* }
            System.out.println("*          *           *           *");

        }*/
        return lpath;

    }

}
